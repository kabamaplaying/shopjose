import { Resolver, Query, Arg, ID, Mutation } from 'type-graphql';
import loadCategories from '../../data/category.data';
import Category from './../../data/entities/category.entity';
import AddCategoryInput from './category.input_type';
import search from '../../helpers/search';
import { CategoryRepository } from '../../data/repository/category.repository';
import { getCustomRepository } from 'typeorm';
@Resolver()
export default class CategoryResolver {

  private readonly categoryRepository = getCustomRepository(CategoryRepository);

  @Query(returns => [Category], { description: 'Get all the categories' })
  async categories(@Arg('type', { nullable: true }) type?: string,
    @Arg('searchBy', { defaultValue: '' }) searchBy?: string): Promise<Category[]> {
    const categorias = await this.categoryRepository.findAll();
    return await search(categorias, ['name'], searchBy);
  }

  @Query(returns => Category)
  async category(@Arg('id', type => ID) id: number): Promise<Category | undefined> {
    return await this.categoryRepository.buscarXId(id);
  }

  @Mutation(() => Category, { description: 'Create Category' })
  async createCategory(@Arg('category') category: AddCategoryInput): Promise<Category> {
    const inserCategory: Category = { ...category };
    return await this.categoryRepository.insertar(inserCategory);
  }
}
