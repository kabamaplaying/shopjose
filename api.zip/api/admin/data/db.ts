import { createConnection, getCustomRepository } from "typeorm";
import { CategoryRepository } from "./repository/category.repository";


export const databaseInitializer = async () => {
    return await createConnection({
        type: "mysql",
        host: "localhost",
        port: 3306,
        username: "root",
        password: "jenny23",
        database: "shop",
        synchronize: true,
        logging: false,
        entities: [
            __dirname   + "./../data/entities/**/*.ts"
        
        ]
    }).then(async(...args) => {
        debugger
        console.log('Conección establecida con la base de datos....');

    }).catch(console.log);
};