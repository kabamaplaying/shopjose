import { Repository, EntityRepository } from "typeorm";
import Product from "../entities/product.entity";


@EntityRepository(Product)
export class ProductRepository extends Repository<Product> {

    async  cargarProductos(): Promise<Product[]> {
        return await this.find();
    }

    async  cargarProducto(slug: string): Promise<Product> {
        const product = await this.findOne({ where: { slug } });
        if (!product) {
            throw new Error(`El producto cons slug ${slug} que estas buscando no esta registrado`);
        }
        return product;
    }

    async insertar(product: Product): Promise<Product> {
        return await this.save(product);
    }

}