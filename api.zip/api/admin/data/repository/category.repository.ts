import { EntityRepository, Repository } from "typeorm";
import Category from "../entities/category.entity";


@EntityRepository(Category)
export class CategoryRepository extends Repository<Category> {

    async findAll(): Promise<Category[]> {
        return await this.find();
    }

    async buscarXId(id: number): Promise<Category> {
        const category = await this.findOne({ where: { id } });
        if (!category) {
            throw new Error(`La categoria ${id} que estas buscando no esta registrada`);
        }
        return category;
    }

    async insertar(category: Category): Promise<Category> {
        return await this.save(category);
    }

}