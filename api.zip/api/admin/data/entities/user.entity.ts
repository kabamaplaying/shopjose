import { BaseEntity, Entity, PrimaryGeneratedColumn, Column, OneToOne, JoinColumn, OneToMany } from "typeorm";
import { ObjectType, Field, ID } from "type-graphql";
import Address from "./address.entity";
import Contact from "./contact.entity";
import Card from "./card.entity";

@ObjectType()
@Entity('user')
export default class User{
  @Field(type => ID)
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Field()
  @Column({nullable: false, type: "varchar"})
  name: string;

  @Field()
  @Column({nullable: true, type: "varchar"})
  image: string;

  @Field()
  @Column({nullable: false, type: "varchar"})
  email: string;

  @Field(type => [Address])
  @OneToMany(type => Address, addresses => addresses.user)
  addresses: Address[];

  @Field(type => [Contact])
  @OneToMany(type => Contact, contacts => contacts.user)
  contacts: Contact[];

  @Field(type => [Card])
  @OneToMany(type => Card, card => card.user)
  card: Card[];

  @Column({nullable: false, type: 'varchar'})
  password: string;

  @Field()
  creation_date: Date;
}

