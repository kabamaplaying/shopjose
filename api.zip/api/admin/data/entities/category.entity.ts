import { Entity, PrimaryGeneratedColumn, Column, BaseEntity, JoinColumn, ManyToOne, OneToOne } from "typeorm";
import { Field, ID, ObjectType } from "type-graphql";
import Product from "./product.entity";

@Entity({ name: 'category', orderBy: { creation_date: 'ASC' } })
@ObjectType()
class Category  {
    @PrimaryGeneratedColumn()
    @Field(type => ID)
    id: number;

    @Column()
    @Field()
    name: string;

    @Column({ nullable: true })
    @Field()
    type: string;

    @Field({ defaultValue: null })
    value: string;

    @Column()
    @Field()
    icon: string;

    @Column()
    @Field()
    slug: string;
    // You should resolve this field by using @FieldResolver decorator within your Category Resolver Class.
    @Column({ default: 0 })
    @Field({ defaultValue: 0 })
    number_of_product?: number;

    @Column({name: 'creation_date'})
    @Field()
    creation_date: Date;

}

export default Category;