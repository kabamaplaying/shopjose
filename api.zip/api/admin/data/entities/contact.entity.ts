import { ObjectType, ID, Field } from 'type-graphql';
import { Entity, ManyToOne, PrimaryGeneratedColumn, Column } from 'typeorm';
import User from './user.entity';

@ObjectType()
@Entity('contact')
export default class Contact {
  @Field(type => ID)
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Field()
  @Column()
  type: string;

  @Field()
  @Column()
  number: string;

  @ManyToOne(type => User, user => user.contacts)
  user: User;
}
