import { ObjectType, ID, Field } from 'type-graphql';
import { Entity, ManyToOne, PrimaryGeneratedColumn, Column } from 'typeorm';
import User from './user.entity';
@ObjectType()
@Entity('contact')
export default class Address {
  @Field(type => ID)
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Field()
  @Column({nullable: false, type: 'varchar'})
  type: string;

  @Field()
  @Column({nullable: false, type: 'varchar'})
  title: string;

  @Field()
  @Column({nullable: false, type: 'varchar'})
  location: string;

  @ManyToOne(type => User, user => user.addresses)
  user: User;
}