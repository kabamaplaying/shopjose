import { ObjectType, ID, Field } from 'type-graphql';
import { ManyToOne, Entity, Column, PrimaryGeneratedColumn } from 'typeorm';
import User from './user.entity';

@ObjectType()
@Entity('card')
export default class Card {
  @Field(type => ID)
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Field()
  @Column({nullable: false, type: 'varchar'})
  type: string;

  @Field()
  @Column({nullable: false, type: 'varchar'})
  title: string;

  @Field()
  @Column({nullable: false, type: 'varchar'})
  cardType: string;

  @Field()
  @Column({nullable: false, type: 'integer'})
  lastFourDigit: number;

  @ManyToOne(type => User, user => user.card)
  user: User;
}
