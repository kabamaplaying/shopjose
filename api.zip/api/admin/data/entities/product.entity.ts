import { ManyToOne, ManyToMany } from 'typeorm';
import Category from './category.entity';
import { Field, ID, Int, Float, ObjectType } from 'type-graphql';
import { Entity, PrimaryGeneratedColumn, Column, OneToMany, JoinColumn, JoinTable, OneToOne } from 'typeorm';

@ObjectType()
@Entity('product')
 class Product {

  @PrimaryGeneratedColumn('uuid')
  @Field(type => ID)
  id: string;

  @Column({nullable: false, type: 'varchar'})
  @Field()
  name: string;

  @Column({nullable: true, type: 'varchar'})
  @Field()
  image: string;

  @Column()
  @Field()
  type: string;

  @Column()
  @Field()
  unit: string;

  @Field(type => [Category])
  @ManyToMany(type => Category)
  @JoinTable()
  categories: Category[];

  @Column()
  @Field(type => Float)
  price: number;

  @Column()
  @Field(type => Float)
  salePrice: number;

  @Column()
  @Field(type => Int)
  discountInPercent: number;

  @Column()
  @Field(type => Int, { defaultValue: 1 })
  per_unit: number;

  @Column()
  @Field(type => Int)
  quantity: number;

  @Column({nullable: true})
  @Field(type => Int, { nullable: true })
  views?: number;

  @Column({nullable: true})
  @Field(type => Int, { nullable: true })
  sales?: number;

  @Column()
  @Field({ nullable: true })
  description?: string;

  @Column()
  @Field()
  creation_date: Date;

  @Column()
  @Field()
  slug: string;
}

export default Product;
