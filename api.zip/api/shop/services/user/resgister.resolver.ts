import { bcrypt } from 'bcryptjs';
import { Mutation, Resolver, Arg } from "type-graphql";

 
@Resolver()
export class RegisterResolver {

    @Mutation(() => String)
    async register(
        @Arg('firsName') firstName: String,
        @Arg('lastName') lastName: String,
        @Arg('email') email: String,
        @Arg('password') password: String
    ) {
    const passworHashed = bcrypt.hash(password, 12);
        return "firstName";
    }
}